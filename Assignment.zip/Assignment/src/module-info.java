module Assignment {
	requires java.desktop;
}