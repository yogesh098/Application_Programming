package Converter.src;

import javax.swing.JFrame;

/**
 * The main driver program for the GUI based conversion program.
 * 
 * @author mdixon
 */
public class Converter {
	 
    public static void main(String[] args) {
    	
        JFrame frame = new JFrame("Converter");
        //frame.setSize(360, 250); //
        frame.setBounds(360, 250, 300, 300);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 
        MainPanel panel = new MainPanel();
        
        frame.setJMenuBar(panel.setupMenu());
    
        frame.getContentPane().add(panel);
        
        frame.pack();
        frame.setVisible(true);
    }
}