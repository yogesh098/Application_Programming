package Converter.src;
import java.awt.Component;
import java.awt.Font;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

/**
 * The main driver program for the GUI based conversion program.
 * 
 * @author Yogesh Bahadur Singh, Bsc(hons)Computing, L5- Section-D
 */
public class Converter {
	 
    public static void main(String[] args) {
    	
    	JFrame frame = new JFrame("Converter");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);     
       
        // Create a new master panel
        JPanel masterPanel = new JPanel();
       
        // Use a box layout to stack the panels
        masterPanel.setLayout(new BoxLayout(masterPanel, BoxLayout.PAGE_AXIS));
       
        MainPanel panel = new MainPanel();
        frame.setJMenuBar(panel.setupMenu());
       
        // Create the new currency panel
        CurrencyPanel currencyPanel = new CurrencyPanel();
        currencyPanel.setBorder(new TitledBorder(null, "Currency Converter", TitledBorder.LEADING, TitledBorder.TOP, null, null));
        currencyPanel.setFont(new Font("Arial", Font.BOLD, 20));
       
        // Add the sub-panels to the master panel
        masterPanel.add(panel);
        masterPanel.add(currencyPanel);
        
        panel.currencyPanel=currencyPanel;
        currencyPanel.mainpanel=panel;
       
        // Add the master panel to the frame
        frame.getContentPane().add(masterPanel);
      
        frame.pack();
        frame.setVisible(true);
}
}
