package Converter.src;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;

/**
 * The main graphical panel used to display conversion components.
 * 
 * This is the starting point for the assignment.
 *  * The variable names have been deliberately made vague and generic, and most comments have been removed.
 * 
 * You may want to start by improving the variable names and commenting what the existing code does.
 * 
 * @author Yogesh Bahadur Singh (C7202814)
 *  */


@SuppressWarnings({ "serial", "unused" })
public class CurrencyPanel extends JPanel  {

public JButton CONVERT;
private static String[] list = {"Euro(EUR)","US Dollar(USD)","Australian Dollars(AUD)","Canadian Dollars(CAD)","Icelandic Krona(ISK)","United Arab Emirates Dirham(AED)","South African Rand(ZAR)","Thai Bhat(THB)" };
public JTextField inputinput;
public JButton openfile;
public MainPanel mainpanel;
@SuppressWarnings("rawtypes")
public JComboBox choosefile;
public JLabel res;
public JFileChooser fileChooser;
public String sy;
ArrayList<String> allerr=new ArrayList<String>();

public void crystalclear() {
inputinput.setText("");
res.setText("result");

}


@SuppressWarnings({ "unchecked", "rawtypes" })
CurrencyPanel(){

ActionListener listener = new ConvertListener();

//Label for input
JLabel input=new JLabel("Enter value:");
input.setBackground(Color.YELLOW);
input.setForeground(Color.RED);
input.setFont(new Font("Arial", Font.BOLD, 20));
input.setToolTipText("Enter the value !");

//textfield to enter the value
inputinput=new JTextField(10);
inputinput.setFont(new Font("Arial", Font.BOLD, 20));
inputinput.setToolTipText("Enter the value: ");

//Label for selecting conversion value
JLabel select=new JLabel("Select currency:");
select.setFont(new Font("Arial", Font.BOLD, 20));
select.setToolTipText("Select the currency: ");


choosefile=new JComboBox(list);
choosefile.setToolTipText("Options !");


CONVERT = new JButton("CONVERT");
CONVERT.addActionListener(listener); 
CONVERT.setToolTipText("CONVERTs the entered value");
CONVERT.setFont(new Font("Arial", Font.BOLD, 20));
CONVERT.setBackground(Color.DARK_GRAY);
CONVERT.setForeground(Color.RED);


inputinput.addKeyListener(new KeyAdapter() {
public void keyPressed(KeyEvent e) {
if(e.getKeyCode()==KeyEvent.VK_ENTER) {
CONVERT.doClick();
}
}
});


//result of the CONVERTed amount

res=new JLabel("RESULT");
res.setToolTipText("Result of the conversion");
res.setBackground(Color.YELLOW);
res.setForeground(Color.RED);
res.setFont(new Font("Arial", Font.BOLD, 20));


   fileChooser= new JFileChooser();
   
   
    
   JButton button=new JButton("Open File...");
   button.setBackground(Color.DARK_GRAY);
   button.setForeground(Color.RED);
   button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                buttonActionPerformed(evt);            
            }
        });
   
button.setToolTipText("Choose a file !");
button.setFont(new Font("Arial", Font.BOLD, 20));

//adding to the panel
add(select);
add(choosefile);
add(button);
add(input);
add(inputinput);
add(CONVERT);
add(res);

setPreferredSize(new Dimension(550, 250));

}


     
private void buttonActionPerformed(java.awt.event.ActionEvent evt) {
   int returnVal = fileChooser.showOpenDialog(this);
   if (returnVal == JFileChooser.APPROVE_OPTION) {
    loadCurrencyFile();
   }
} 

Boolean validation(String line) {
Boolean hasError = false;
String errorLine = "";
String [] parts = line.split(",");

try {
if(parts.length != 3) {
if(errorLine == "") {
errorLine = errorLine + line;
}
errorLine = errorLine + " Don't have 3 commas";
hasError = true;
}

}catch(Exception e) {
// e.printStackTrace();
}

//check for valid factor
try {
Double d = Double.parseDouble(parts[1].trim());

}catch(Exception e) {
if(errorLine == "") {
errorLine = errorLine + line;
}
errorLine =errorLine + "Invalid factor";
hasError = true;
// e.printStackTrace();
}

allerr.add(errorLine);
return hasError;
}

@SuppressWarnings("unchecked")
void loadCurrencyFile() {       

       File file = fileChooser.getSelectedFile();
      
       try {
        ArrayList<String> nextCombo=new ArrayList<String>();
           BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF8"));
          
           String line = in.readLine();
          
           while ( line != null ) {
               // Process 'line' (split up).
               String [] parts = line.split(",");
               
              if(!validation(line)) { 
              nextCombo.add(parts[0].trim());
              }
              line = in.readLine();
           }
              //converting array list of string to array of string 
              String[] Array= new String[nextCombo.size()];
              Array=nextCombo.toArray(Array);
              
              //assigning new combo list to exsisting combo list
              
              list=Array;
              System.out.println(list);
              choosefile.removeAllItems();
              for(String comboItem:list)
              {
              choosefile.addItem(comboItem);
              }
              
             if(allerr.size()>0) {
            String errorPara = "";
            for(String error : allerr) {
            errorPara += error;
            }
            
            JOptionPane.showMessageDialog(null, errorPara);
             }
              
       
           in.close();
       }
       
       catch (Exception e) {
          
           // Something went wrong.
        // show the message to the user!
        JOptionPane.showMessageDialog(null,"File not selected !");
          
           
       }

}


//For two decimal places




private class ConvertListener implements ActionListener {

@Override
public void actionPerformed(ActionEvent event) {

double value;

//Trims the white spaces of the entered value 
String text = inputinput.getText().trim();

//Checking if the textbox if empty or not 
if (text.isEmpty() == false) {

try {
value = Double.parseDouble(text);

} 

//Error if the entered value is other than number 
catch (NumberFormatException e) {

JOptionPane.showMessageDialog(null, "Enter correct type!");
return;
}



// The factor applied during the conversion
double factor = 0;

// The offset applied during the conversion.
double offset = 0;



// Setup the correct factor/offset values depending on required conversion
switch (choosefile.getSelectedIndex()) {

case 0:// Euro(EUR)

//calling method from main panel
if(mainpanel.ReverseSelected()) {
	
factor=1/1.06;
}

else {
factor = 1.06;
}
break;


case 1:
	sy="€";
if(mainpanel.ReverseSelected()) {
factor=1/1.14;
}

else {
factor = 1.14;
}
break;


case 2:
	sy="$";
if(mainpanel.ReverseSelected()) {
factor=1/1.52;
}

else {
factor = 1.52;
}
break;


case 3:
	sy="$";
if(mainpanel.ReverseSelected()) {
factor=1/1.77;
}

else {
factor = 1.77;
}
break;


case 4:
	sy="$";
if(mainpanel.ReverseSelected()) {
factor=1/130.62;
}

else {
factor = 130.62;
}
break;


case 5:
	sy="kr";
if(mainpanel.ReverseSelected()) {
factor=1/4.60;
}

else {
factor=4.60;
}
break;


case 6:
	sy="د.إ";
if(mainpanel.ReverseSelected()) {
factor=1/17.96;

}

else {
factor =17.96;
}
break;


case 7:
	sy="R";
if(mainpanel.ReverseSelected()) {
factor=1/44.28;

}

else {
factor=44.28;
}

break;

}



//For the result for the conversion from the combo box 
double result;

result = factor * value + offset;

DecimalFormat decimalFormat=new DecimalFormat("0.##");
String rslt2= sy+decimalFormat.format(result);
//Using decimal format to print the value upto two decimal places 
res.setText(decimalFormat.format(result));

//Counting the number of conversions done 
mainpanel.ConversionCount();

}

   //If the user does not enter any value 
else {
JOptionPane.showMessageDialog(null, "Enter a number!");
}
}
}
}