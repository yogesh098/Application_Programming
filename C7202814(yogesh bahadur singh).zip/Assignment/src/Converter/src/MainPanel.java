package Converter.src;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
//import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.DecimalFormat;
import java.util.regex.Pattern;

import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
//import javax.swing.ImageIcon;
//import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

/**
 * The main graphical panel used to display conversion components.
 * 
 * This is the starting point for the assignment.
 *  * The variable names have been deliberately made vague and generic, and most comments have been removed.
 * 
 * You may want to start by improving the variable names and commenting what the existing code does.
 * 
 * @author Yogesh Bahadur Singh (C7202814)
 *  */
@SuppressWarnings({ "serial", "unused" })
public class MainPanel extends JPanel {

	private final static String[] list = { "inches/cm", "celcious/ferenhite", "Miles/Nautical Miles", "Acres/Hectares","Miles per hour/Kilometres per hour", "Yards/Meters", "Degrees/Radians" };
	private JTextField textField;
	private JLabel label;
	private JComboBox<String> combo;
	private JCheckBox reverse;
	private JButton convertButton;
	private JLabel count;
	private int no = 0;
	public CurrencyPanel currencyPanel;
	
	JMenuBar setupMenu() {

		JMenuBar ant = new JMenuBar();
		JMenu y1 = new JMenu("File");
		y1.setToolTipText("Click to know more !!");
		Font f = new Font("Arial",Font.BOLD,20);
		y1.setFont(f);
		y1.setBackground(Color.YELLOW);
		y1.setForeground(Color.RED);
		
		JMenu y2 = new JMenu("Option");
		y2.setToolTipText("Click to know more !!");
		Font g = new Font("Arial",Font.BOLD,20);
		y2.setFont(g);
		y2.setBackground(Color.YELLOW);
		y2.setForeground(Color.RED);
		
		JMenu y3 = new JMenu("Help");
		y3.setToolTipText("Click to know more !!");
		Font h = new Font("Arial",Font.BOLD,20);
		y3.setFont(h);
		y3.setBackground(Color.YELLOW);
		y3.setForeground(Color.RED);
		

		ant.add(y1);
		ant.add(y2);
		ant.add(y3);
		
		//adding sub-menu in the menu bar

		JMenuItem yo1 = new JMenuItem("SAVE");
		yo1.setToolTipText("Click to Save !!");
		Font p = new Font("Arial",Font.BOLD,20);
		yo1.setFont(p);
		yo1.setBackground(Color.YELLOW);
		yo1.setForeground(Color.RED);
		yo1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent E) {
				JOptionPane.showMessageDialog(null, "Your file is saved.");
			}
		});
	      y1.add(yo1);
		
		JMenuItem yo2 = new JMenuItem("PRINT");
		yo2.setToolTipText("Click to Print !!");
		Font l = new Font("Arial",Font.BOLD,20);
		yo2.setFont(l);
		yo2.setBackground(Color.YELLOW);
		yo2.setForeground(Color.RED);
		yo2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent E) {
				JOptionPane.showMessageDialog(null, "Your file is printed.");
			}
		});
		y1.add(yo2);
		
		JMenuItem yo3 = new JMenuItem("EXIT");
		yo3.setToolTipText("Click to Exit !!");
		Font m = new Font("Arial",Font.BOLD,20);
		yo3.setFont(m);
		yo3.setBackground(Color.YELLOW);
		yo3.setForeground(Color.RED);
		yo3.setIcon(new ImageIcon("logout.PNG"));
		yo3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent E) {
				System.exit(0);
			}
		});
		y1.add(yo3);
		
		JMenuItem yo4 = new JMenuItem("About");
		yo4.setToolTipText("Click to know about Author. !!");
		Font n = new Font("Arial",Font.BOLD,20);
		yo4.setFont(n);
		yo4.setBackground(Color.YELLOW);
		yo4.setForeground(Color.RED);
		yo4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent E) {
				JOptionPane.showMessageDialog(null, "This application can be used in purpose of conversion of different units. \nAuthor:Yogesh Singh Thakuri \n@Copyright 2019");
			}
		});
		y3.add(yo4);
		
		//adding Mnemonic for sub menu 
	    y1.setMnemonic(KeyEvent.VK_F);
		y2.setMnemonic(KeyEvent.VK_O);
		y3.setMnemonic(KeyEvent.VK_H);
		yo1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,InputEvent.CTRL_DOWN_MASK));
		yo2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P,InputEvent.CTRL_DOWN_MASK));
		yo3.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,InputEvent.CTRL_DOWN_MASK));
		yo4.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,InputEvent.CTRL_DOWN_MASK));

		return ant;
	}


	MainPanel() {

		ActionListener listener = new ConvertListener();
		ActionListener combolistener = new ComboboxListener();

		combo = new JComboBox<String>(list);
		combo.addActionListener(combolistener); //convert values when option changed
		combo.setToolTipText("Change to convert !");
		

		JLabel inputLabel = new JLabel("Enter value:");
		inputLabel.setBackground(Color.YELLOW);
		inputLabel.setForeground(Color.RED);
		Font p = new Font("Arial",Font.BOLD,20);
		inputLabel.setFont(p);
		inputLabel.setToolTipText("ENTER VALUE !!");
		count = new JLabel("Count: 0");
		count.setToolTipText("Counting times");
		

		convertButton = new JButton("CONVERT");
		convertButton.setBackground(Color.DARK_GRAY);
		convertButton.setForeground(Color.RED);
		convertButton.setBounds(31, 236, 71, 27);
		Font u = new Font("Arial",Font.BOLD,20);
		convertButton.setFont(u);
		convertButton.setToolTipText("Click !!");
		convertButton.addActionListener(listener); // convert values when pressed
		
		
		JButton clear = new JButton("CLEAR");
		clear.setBackground(Color.lightGray);
		clear.setForeground(Color.RED);
		Font t = new Font("Arial",Font.BOLD,20);
		clear.setFont(t);
		clear.setToolTipText("Click to CLEAR !!");
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent E) {
				label.setText("result");
				textField.setText(null);
				no = 0;
				count.setText("Count: "+no);
				count.setToolTipText("Count a value !!");
				currencyPanel.crystalclear();
			}
		});
		
		
		label = new JLabel("RESULT");
		Font w = new Font("Arial",Font.BOLD,20);
		label.setFont(w);
		label.setToolTipText("Result");
		textField = new JTextField(15);
		textField.setToolTipText("Enter a value");
		textField.setBackground(Color.LIGHT_GRAY);
		textField.setForeground(Color.BLACK);
		Font n = new Font("Arial",Font.BOLD,20);
		textField.setFont(n);
		textField.setToolTipText("Enter a value !!");
		textField.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER) {
					convertButton.doClick();
				}
			}
		});
		
		
		reverse = new JCheckBox("Reverse Conversion : ");
		Font l = new Font("Arial",Font.BOLD,20);
		reverse.setFont(l);
		reverse.setToolTipText("Reverse a value !!");
	//	CurrencyPanel.clr();
		
		
		
		add(combo);
		add(inputLabel);
		add(textField);
		add(convertButton);
		add(label);
		add(reverse);
		add(clear);
		add(count);
		setPreferredSize(new Dimension(800, 80));
		setBackground(Color.LIGHT_GRAY);
		reverse.setOpaque(false);
		
		setPreferredSize(new Dimension(550, 250));
	}


	private class ComboboxListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent event) {
			if(no!=0) {
				convertButton.doClick();
			}
		}
	};
	private class ConvertListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {

			String text = textField.getText().trim();
			
			boolean a = reverse.isSelected();

			if (text.isEmpty() == false) {
				if(Pattern.matches("[0-9]*", text)) {
				
				double value = Double.parseDouble(text);

				// the factor applied during the conversion
				double factor = 0;
				
				// the offset applied during the conversion.
				double offset = 0;

				// Setup the correct factor/offset values depending on required conversion
				
				switch (combo.getSelectedIndex()) {
				
				case 0: // inches/cm
					if(a) {
					factor = (1/2.54);
					}
					else {
					factor = 2.54;
				}
					break;
					
				case 1: //Celsius/Fahrenheit
					if (a) {
					factor =  (5.0/9.0);
					offset = -32;
					}
					else {
					   factor = 9.0/5.0;
					   offset = 32;
					}
				//	offset = 32;
					break;
					
				case 2: //miles/nautical miles
					if(a) {
						factor = (1/1.15078);
					}
					else {
					factor =  1.15078;
					}
					break;
					
				case 3: //Acres/Hectares
					if(a) {
					factor = (1/2.47105382);
					}else {
						factor = 2.47105382;
					}
					break;
					
				case 4: //Miles per hour/Kilometres per hour
					if(a){
					factor = (1/1.61);
					}else {
						factor = 1.61;
					}
					break;
					
				case 5: //yards/meter
					if(a) {
					factor = (1/0.9144);
					}else {
						factor = 0.9144;
					}
					break;
					
				case 6: //radian/degree
				if(a){
					factor = (1/0.0175);
				}
				else{
					factor = 0.0175;	
					}
					break;
					
				}
				double result;
				if(a && combo.getSelectedIndex() == 1) {
					result = factor * (value + offset);
				}else {
					result = factor * value + offset;
				}
							
				DecimalFormat decimalFormat= new DecimalFormat("#.##");
				String finalResult = decimalFormat.format(result);
				label.setText(finalResult);
				no++;
				count.setText("Count :: "+no);
			}
				else {
					JOptionPane.showMessageDialog(null, "Invalid Characters !!");
				}
			}
			else {
				JOptionPane.showMessageDialog(null, "Empty textfield !!");
			}
		}
	}
	public boolean ReverseSelected() {
		// TODO Auto-generated method stub
		boolean re=reverse.isSelected();
		return re;
	}


	public void ConversionCount() {
		//AbstractButton counter;
		// TODO Auto-generated method stub
		no++;
		count.setText("counter conversion  = " +Integer.toOctalString(no));
		
	}

}








